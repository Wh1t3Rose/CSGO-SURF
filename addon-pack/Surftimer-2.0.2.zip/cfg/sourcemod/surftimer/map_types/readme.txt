You can create a new map config using the maps prefix.
Examples: kzpro_.cfg, mg_.cfg, rj_.cfg, etc.
